#include <iostream>
#include "Lista.h"
using namespace std;

int main()
{
	//Crear el objeto lista
	Lista<int>* lista = new Lista<int>;
	lista->agregarInicial(10);
	lista->agregarInicial(20);
	lista->agregarInicial(30);
	lista->agregarInicial(40);
	lista->agregarInicial(50);

	//Numero de elementos
	cout << "Numero de elementos: " << lista->longitud() << endl;

	//Mostrando los elementos de la lista
	for (int i = 0; i < lista->longitud(); i++)
		cout << i << " => " << lista->obtenerPos(i) << endl;

	//Eliminar elemento del inicio
	lista->eliminarInicial();
	cout << endl;
	for (int i = 0; i < lista->longitud(); i++)
		cout << i << " => " << lista->obtenerPos(i) << endl;

	return 0;
}
